package mod.moineau.contentpacks.block.contextpredicate.typed;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;
import org.jetbrains.annotations.ApiStatus;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public sealed class WhitelistTypedBlockContextPredicate<A> implements TypedBlockContextPredicate<A> {
    private final List<A> list;

    public WhitelistTypedBlockContextPredicate(List<A> list) {
        this.list = list;
    }

    public static <A> MapCodec<WhitelistTypedBlockContextPredicate<A>> createCodec(Codec<A> typeCodec) {
        return typeCodec.listOf().xmap(WhitelistTypedBlockContextPredicate::new, WhitelistTypedBlockContextPredicate::list).fieldOf("values");
    }

    @Override
    public boolean test(BlockState state, BlockView world, BlockPos pos, A type) {
        return list().contains(type);
    }

    @Override
    public TypedBlockContextPredicateType<?> getType() {
        return TypedBlockContextPredicateType.WHITELIST;
    }

    public List<A> list() {
        return list;
    }

    @ApiStatus.Internal
    public static final class Lazy<A> extends WhitelistTypedBlockContextPredicate<A> {
        private final Supplier<List<A>> lazyList;
        private boolean loaded;

        public Lazy(Supplier<List<A>> list) {
            super(new ArrayList<>());
            this.lazyList = list;
        }

        @Override
        public boolean test(BlockState state, BlockView world, BlockPos pos, A type) {
            return super.test(state, world, pos, type);
        }

        @Override
        public List<A> list() {
            if (!loaded) {
                super.list.addAll(lazyList.get());
                loaded = true;
            }
            return super.list;
        }
    }
}
