package mod.moineau.contentpacks.block.contextpredicate.typed;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import java.util.List;
import java.util.function.Function;

abstract class CombinedTypedBlockContextPredicate<A> implements TypedBlockContextPredicate<A> {
	protected final List<TypedBlockContextPredicate<A>> predicates;

	protected CombinedTypedBlockContextPredicate(List<TypedBlockContextPredicate<A>> predicates) {
		this.predicates = predicates;
	}

	public static <A, T extends CombinedTypedBlockContextPredicate<A>> MapCodec<T> buildCodec(Function<List<TypedBlockContextPredicate<A>>, T> combiner, Codec<A> typeCodec) {
		return RecordCodecBuilder.mapCodec(
			instance -> instance.group(TypedBlockContextPredicate.createCodec(typeCodec).listOf().fieldOf("predicates").forGetter(predicate -> predicate.predicates)).apply(instance, combiner)
		);
	}
}
