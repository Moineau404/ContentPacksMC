package mod.moineau.contentpacks.block.contextpredicate.typed;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;

import java.util.List;

public class AnyOfTypedBlockContextPredicate<A> extends CombinedTypedBlockContextPredicate<A> {
	public static <A> MapCodec<AnyOfTypedBlockContextPredicate<A>> createCodec(Codec<A> typeCodec) {
		return buildCodec(AnyOfTypedBlockContextPredicate::new, typeCodec);
	}

	public AnyOfTypedBlockContextPredicate(List<TypedBlockContextPredicate<A>> list) {
		super(list);
	}

	public boolean test(BlockState state, BlockView world, BlockPos pos, A type) {
		for (TypedBlockContextPredicate<A> typedBlockContextPredicateType : this.predicates) {
			if (typedBlockContextPredicateType.test(state, world, pos, type)) {
				return true;
			}
		}

		return false;
	}

	@Override
	public TypedBlockContextPredicateType<?> getType() {
		return TypedBlockContextPredicateType.ANY_OF;
	}
}
