package mod.moineau.contentpacks.block.contextpredicate.typed;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;

public abstract class AlwaysTypedBlockContextPredicate<A> implements TypedBlockContextPredicate<A> {
	public static final AlwaysTypedBlockContextPredicate<?> TRUE = new AlwaysTypedBlockContextPredicate<>() {
		public boolean test(BlockState state, BlockView world, BlockPos pos, Object type) {
			return true;
		}

		@Override
		public TypedBlockContextPredicateType<?> getType() {
			return TypedBlockContextPredicateType.TRUE;
		}
	};
	public static final AlwaysTypedBlockContextPredicate<?> FALSE = new AlwaysTypedBlockContextPredicate<>() {
		public boolean test(BlockState state, BlockView world, BlockPos pos, Object type) {
			return false;
		}

		@Override
		public TypedBlockContextPredicateType<?> getType() {
			return TypedBlockContextPredicateType.FALSE;
		}
	};

	@SuppressWarnings("unchecked")
    public static <A> AlwaysTypedBlockContextPredicate<A> createTrue() {
		return (AlwaysTypedBlockContextPredicate<A>) TRUE;
	}

	@SuppressWarnings("unchecked")
    public static <A> AlwaysTypedBlockContextPredicate<A> createFalse() {
		return (AlwaysTypedBlockContextPredicate<A>) FALSE;
	}

	public static <A> MapCodec<? extends TypedBlockContextPredicate<A>> createTrueCodec(Codec<A> typeCodec) {
		return MapCodec.unit(createTrue());
	}

	public static <A> MapCodec<? extends TypedBlockContextPredicate<A>> createFalseCodec(Codec<A> typeCodec) {
		return MapCodec.unit(createFalse());
	}
}
