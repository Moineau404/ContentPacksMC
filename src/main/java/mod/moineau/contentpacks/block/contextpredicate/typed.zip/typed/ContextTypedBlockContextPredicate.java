package mod.moineau.contentpacks.block.contextpredicate.typed;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import mod.moineau.contentpacks.block.contextpredicate.BlockContextPredicate;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;

public record ContextTypedBlockContextPredicate<A>(BlockContextPredicate predicate) implements TypedBlockContextPredicate<A> {
    private static final Codec<ContextTypedBlockContextPredicate<?>> BASE_CODEC = BlockContextPredicate.BASE_CODEC.xmap(
            ContextTypedBlockContextPredicate::new,
            ContextTypedBlockContextPredicate::predicate
    );
    private static final MapCodec<ContextTypedBlockContextPredicate<?>> CODEC = BASE_CODEC.fieldOf("predicate");

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static <A> Codec<? extends TypedBlockContextPredicate<A>> createBaseCodec(Codec<A> typeCodec) {
        return (Codec) BASE_CODEC;
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static <A> MapCodec<? extends TypedBlockContextPredicate<A>> createCodec(Codec<A> typeCodec) {
        return (MapCodec) CODEC;
    }

    @Override
    public boolean test(BlockState state, BlockView world, BlockPos pos, Object type) {
        return predicate.test(state, world, pos);
    }

    @Override
    public TypedBlockContextPredicateType<?> getType() {
        return TypedBlockContextPredicateType.CONTEXT_PREDICATE;
    }
}
