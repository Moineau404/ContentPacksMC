package mod.moineau.contentpacks.block.contextpredicate.typed;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;

public class NotTypedBlockContextPredicate<A> implements TypedBlockContextPredicate<A> {
	public static <A> MapCodec<NotTypedBlockContextPredicate<A>> createCodec(Codec<A> typeCodec) {
		return RecordCodecBuilder.mapCodec(
				instance -> instance.group(TypedBlockContextPredicate.createCodec(typeCodec).fieldOf("predicate").forGetter(predicate -> predicate.predicate))
						.apply(instance, NotTypedBlockContextPredicate::new)
		);
	}

	private final TypedBlockContextPredicate<A> predicate;

	public NotTypedBlockContextPredicate(TypedBlockContextPredicate<A> predicate) {
		this.predicate = predicate;
	}

	public boolean test(BlockState state, BlockView world, BlockPos pos, A type) {
		return !this.predicate.test(state, world, pos, type);
	}

	@Override
	public TypedBlockContextPredicateType<?> getType() {
		return TypedBlockContextPredicateType.NOT;
	}
}
