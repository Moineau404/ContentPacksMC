package mod.moineau.contentpacks.block.contextpredicate.typed;

import com.mojang.serialization.Codec;
import mod.moineau.contentpacks.api.util.CodecUtil;
import mod.moineau.contentpacks.registry.ContentRegistries;
import net.minecraft.block.AbstractBlock;

// TODO Find a better way to delegate to BlockContextPredicate
public interface TypedBlockContextPredicate<A> extends AbstractBlock.TypedContextPredicate<A> {
	private static <A> Codec<TypedBlockContextPredicate<A>> createBaseCodec(Codec<A> typeCodec) {
		return ContentRegistries.TYPED_BLOCK_CONTEXT_PREDICATE_TYPE.getCodec()
				.dispatch(TypedBlockContextPredicate::getType, type -> type.codec(typeCodec));
	}

	static <A> Codec<TypedBlockContextPredicate<A>> createCodec(Codec<A> typeCodec) {
		return Codec.withAlternative(createBaseCodec(typeCodec), ContextTypedBlockContextPredicate.createBaseCodec(typeCodec));
	}

	@Deprecated
	static <A> Codec<AbstractBlock.TypedContextPredicate<A>> createDowngradedCodec(Codec<A> typeCodec) {
		return CodecUtil.downgrade(createCodec(typeCodec), true);
	}

	TypedBlockContextPredicateType<?> getType();
}
