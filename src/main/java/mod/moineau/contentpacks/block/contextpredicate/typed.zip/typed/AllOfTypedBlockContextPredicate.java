package mod.moineau.contentpacks.block.contextpredicate.typed;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;

import java.util.List;

public class AllOfTypedBlockContextPredicate<A> extends CombinedTypedBlockContextPredicate<A> {
	public static <A> MapCodec<AllOfTypedBlockContextPredicate<A>> createCodec(Codec<A> typeCodec) {
		return buildCodec(AllOfTypedBlockContextPredicate::new, typeCodec);
	}

	public AllOfTypedBlockContextPredicate(List<TypedBlockContextPredicate<A>> list) {
		super(list);
	}

	public boolean test(BlockState state, BlockView world, BlockPos pos, A type) {
		for (TypedBlockContextPredicate<A> typedBlockContextPredicate : this.predicates) {
			if (!typedBlockContextPredicate.test(state, world, pos, type)) {
				return false;
			}
		}

		return true;
	}

	@Override
	public TypedBlockContextPredicateType<?> getType() {
		return TypedBlockContextPredicateType.ALL_OF;
	}
}
