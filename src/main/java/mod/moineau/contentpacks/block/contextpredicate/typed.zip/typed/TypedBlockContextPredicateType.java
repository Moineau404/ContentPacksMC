package mod.moineau.contentpacks.block.contextpredicate.typed;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import mod.moineau.contentpacks.ContentPacks;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public interface TypedBlockContextPredicateType<P extends TypedBlockContextPredicate<?>> {
	TypedBlockContextPredicateType<AnyOfTypedBlockContextPredicate<?>> ANY_OF = AnyOfTypedBlockContextPredicate::createCodec;
	TypedBlockContextPredicateType<AllOfTypedBlockContextPredicate<?>> ALL_OF = AllOfTypedBlockContextPredicate::createCodec;
	TypedBlockContextPredicateType<NotTypedBlockContextPredicate<?>> NOT = NotTypedBlockContextPredicate::createCodec;
	TypedBlockContextPredicateType<AlwaysTypedBlockContextPredicate<?>> TRUE = AlwaysTypedBlockContextPredicate::createTrueCodec;
	TypedBlockContextPredicateType<AlwaysTypedBlockContextPredicate<?>> FALSE = AlwaysTypedBlockContextPredicate::createFalseCodec;
	TypedBlockContextPredicateType<ContextTypedBlockContextPredicate<?>> CONTEXT_PREDICATE = ContextTypedBlockContextPredicate::createCodec;
	TypedBlockContextPredicateType<WhitelistTypedBlockContextPredicate<?>> WHITELIST = WhitelistTypedBlockContextPredicate::createCodec;

	<A> MapCodec<? extends TypedBlockContextPredicate<A>> codec(Codec<A> typeCodec);

	static void initialize(Registry<TypedBlockContextPredicateType<?>> registry) {
		Registry.register(registry, "any_of", ANY_OF);
		Registry.register(registry, "all_of", ALL_OF);
		Registry.register(registry, "not", NOT);
		Registry.register(registry, "true", TRUE);
		Registry.register(registry, "false", FALSE);
		Registry.register(registry, "context_predicate", CONTEXT_PREDICATE);
		Registry.register(registry, Identifier.of(ContentPacks.MOD_ID, "whitelist"), WHITELIST);
	}
}
